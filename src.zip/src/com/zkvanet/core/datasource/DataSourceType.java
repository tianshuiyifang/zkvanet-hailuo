package com.zkvanet.core.datasource;

public enum DataSourceType {
	dataSource
}
