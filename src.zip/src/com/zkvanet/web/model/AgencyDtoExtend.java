package com.zkvanet.web.model;

import java.io.Serializable;

import com.carnet.admin.dto.AgencyDto;

public class AgencyDtoExtend extends AgencyDto  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
